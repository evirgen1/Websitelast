document.addEventListener('DOMContentLoaded', function() {
  // Find all year headers
  var headers = document.querySelectorAll('.year-header');
  
  // Add click event to each header
  headers.forEach(function(header) {
    header.addEventListener('click', function() {
      // Get the content element (next sibling)
      var content = this.nextElementSibling;
      var icon = this.querySelector('.toggle-icon');
      
      // Toggle display
      if (content.style.display === "none" || content.style.display === "") {
        content.style.display = "block";
        icon.textContent = "−"; // Change to minus sign
      } else {
        content.style.display = "none";
        icon.textContent = "+"; // Change back to plus sign
      }
    });
  });
}); 